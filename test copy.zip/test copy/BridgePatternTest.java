/**
 * 
 */
/**
 * @author shivakavya
 *
 */
package test;

import test.Shape;
import test.RedColor;
import test.GreenColor;
import test.Triangle;
import test.Pentagon;

public class BridgePatternTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape tri = new Triangle(new RedColor());
		tri.applyColor();
		
		Shape pent = new Pentagon(new GreenColor());
		pent.applyColor();

	}

}