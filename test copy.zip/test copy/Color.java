package test;

public interface Color {

	public void applyColor();
	
}
