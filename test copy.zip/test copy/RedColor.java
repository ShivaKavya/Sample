package test;

public class RedColor implements Color {
	
public void applyColor() {
		
		System.out.println("Red.");
		
	}

}
